// main.js
// Electron main process for Pixel Lumo.
//
// Two windows:
//  - the overlay window: a small transparent frameless window that IS Lumo.
//    It repositions itself along the bottom of the screen as Lumo "walks".
//  - the chat window: a normal window opened on double-click.
//
// The Claude API call lives here (main process), never in the renderer,
// so an API key never sits in devtools-inspectable code.

const { app, BrowserWindow, ipcMain, screen, globalShortcut } = require('electron');
const path = require('path');
const fs = require('fs');
const { Store } = require('./store');

const WIN_W = 160;
const WIN_H = 170;

let overlayWindow = null;
let chatWindow = null;
let store = null;
let apiKey = null;

function loadApiKey() {
  // Looks for config.json next to the app (see config.example.json).
  // Falls back to an env var so you're not forced to keep a key on disk.
  const configPath = path.join(__dirname, 'config.json');
  if (fs.existsSync(configPath)) {
    try {
      const cfg = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      if (cfg.anthropicApiKey) return cfg.anthropicApiKey;
    } catch (err) {
      console.error('[main] could not parse config.json:', err.message);
    }
  }
  return process.env.ANTHROPIC_API_KEY || null;
}

function workArea() {
  return screen.getPrimaryDisplay().workArea;
}

function createOverlayWindow() {
  const wa = workArea();
  const startX = wa.x + 40;
  const startY = wa.y + wa.height - WIN_H;

  overlayWindow = new BrowserWindow({
    width: WIN_W,
    height: WIN_H,
    x: startX,
    y: startY,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
    resizable: false,
    movable: false,
    skipTaskbar: true,
    hasShadow: false,
    focusable: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  overlayWindow.setAlwaysOnTop(true, 'floating');
  overlayWindow.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  overlayWindow.loadFile(path.join(__dirname, 'overlay', 'index.html'));

  overlayWindow.on('closed', () => {
    overlayWindow = null;
  });
}

function createChatWindow() {
  if (chatWindow) {
    chatWindow.show();
    chatWindow.focus();
    return;
  }

  const wa = workArea();
  chatWindow = new BrowserWindow({
    width: 380,
    height: 520,
    minWidth: 320,
    minHeight: 400,
    x: wa.x + wa.width - 420,
    y: wa.y + wa.height - 560,
    title: 'Lumo',
    backgroundColor: '#14131c',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  chatWindow.setMenuBarVisibility(false);
  chatWindow.loadFile(path.join(__dirname, 'chat', 'chat.html'));

  chatWindow.on('closed', () => {
    chatWindow = null;
  });
}

// ---- IPC: overlay window movement ----
ipcMain.on('set-window-x', (event, desiredX) => {
  if (!overlayWindow) return;
  const wa = workArea();
  const minX = wa.x;
  const maxX = wa.x + wa.width - WIN_W;
  const clampedX = Math.max(minX, Math.min(maxX, Math.round(desiredX)));
  const y = wa.y + wa.height - WIN_H;
  overlayWindow.setBounds({ x: clampedX, y, width: WIN_W, height: WIN_H });
});

ipcMain.handle('get-screen-bounds', () => {
  const wa = workArea();
  return { workArea: wa, winWidth: WIN_W, winHeight: WIN_H };
});

ipcMain.handle('get-cursor-point', () => {
  return screen.getCursorScreenPoint();
});

ipcMain.on('open-chat', () => createChatWindow());
ipcMain.on('quit-app', () => app.quit());

// ---- IPC: stats / memory / xp, shared by overlay + chat ----
ipcMain.handle('get-stats', () => store.getStats());
ipcMain.handle('add-xp', (e, amount) => store.addXp(amount));
ipcMain.handle('adjust-stat', (e, { key, delta }) => store.adjustStat(key, delta));
ipcMain.handle('add-friendship', (e, amount) => store.addFriendship(amount));
ipcMain.handle('get-memory', () => store.getMemory());
ipcMain.handle('remember-fact', (e, fact) => store.rememberFact(fact));
ipcMain.handle('get-chat-history', () => store.getChatHistory());

// ---- IPC: chat -> Claude API (server-side, key never touches renderer) ----
ipcMain.handle('chat-send', async (event, userMessage) => {
  store.pushChatMessage('user', userMessage);

  if (!apiKey) {
    const offline = offlineReply(userMessage);
    store.pushChatMessage('assistant', offline);
    store.addXp(2);
    store.addFriendship(1);
    return { text: offline, offline: true };
  }

  const memory = store.getMemory().slice(-15).map(m => `- ${m.fact}`).join('\n');
  const history = store.getChatHistory().slice(-12); // recent context window

  const systemPrompt = [
    "You are Lumo, a small pixel companion who lives on the edge of the user's screen.",
    'Speak in short, warm, slightly playful lines (1-3 sentences). You are not a generic assistant persona — you are a tiny creature with your own moods.',
    'If the user shares something worth remembering (a name, a preference, an ongoing project), say so naturally; the app will store it separately.',
    memory ? `Things you remember about the user:\n${memory}` : ''
  ].filter(Boolean).join('\n\n');

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 300,
        system: systemPrompt,
        messages: [
          ...history.map(h => ({ role: h.role, content: h.content })),
          { role: 'user', content: userMessage }
        ]
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('[main] Claude API error:', response.status, errText);
      const fallback = "Hmm, I couldn't reach my thoughts just now. Try again in a bit?";
      store.pushChatMessage('assistant', fallback);
      return { text: fallback, offline: false, error: true };
    }

    const data = await response.json();
    const text = (data.content || [])
      .filter(block => block.type === 'text')
      .map(block => block.text)
      .join('\n')
      .trim() || '...';

    store.pushChatMessage('assistant', text);
    store.addXp(4);
    store.addFriendship(2);
    return { text, offline: false };
  } catch (err) {
    console.error('[main] chat-send failed:', err);
    const fallback = "My thoughts got a little tangled. Ask me again?";
    store.pushChatMessage('assistant', fallback);
    return { text: fallback, offline: false, error: true };
  }
});

function offlineReply(message) {
  // Small canned-response set so the app is fully playable with zero setup.
  // Once config.json has a real key, real Claude replies replace this.
  const lower = message.toLowerCase();
  if (/\bjoke\b/.test(lower)) {
    return "Why did the cursor break up with the icon? It needed more space. 😄";
  }
  if (/\b(hi|hello|hey)\b/.test(lower)) {
    return "Hi! I've been watching you work from down here. What's going on?";
  }
  if (/\bname\b/.test(lower)) {
    return "I'm Lumo! Add an Anthropic API key in config.json and I'll actually think for myself.";
  }
  return "I'm running in offline mode right now — add your Anthropic API key to config.json so I can really talk. For now: noted!";
}

// ---- Global shortcut: "call" Lumo to walk toward the cursor ----
function registerShortcuts() {
  globalShortcut.register('Alt+L', () => {
    if (!overlayWindow) return;
    const point = screen.getCursorScreenPoint();
    overlayWindow.webContents.send('call-to-cursor', point);
  });
}

app.whenReady().then(() => {
  store = new Store(app.getPath('userData'));
  apiKey = loadApiKey();
  createOverlayWindow();
  registerShortcuts();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createOverlayWindow();
  });
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
