// chat.js
const messagesEl = document.getElementById('messages');
const inputEl = document.getElementById('input');
const sendBtn = document.getElementById('send');
const lvlEl = document.getElementById('lvl');
const friendEl = document.getElementById('friend');

function addMessage(role, text) {
  const div = document.createElement('div');
  div.className = `msg ${role}`;
  div.textContent = text;
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return div;
}

function addTyping() {
  const div = document.createElement('div');
  div.className = 'msg typing';
  div.textContent = 'Lumo is thinking...';
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return div;
}

async function refreshStats() {
  const stats = await window.lumo.getStats();
  lvlEl.textContent = stats.level;
  friendEl.textContent = stats.friendship;
}

async function loadHistory() {
  const history = await window.lumo.getChatHistory();
  if (history.length === 0) {
    addMessage('assistant', "Hi, I'm Lumo! What's up?");
    return;
  }
  history.forEach(h => addMessage(h.role, h.content));
}

async function send() {
  const text = inputEl.value.trim();
  if (!text) return;
  inputEl.value = '';
  inputEl.style.height = 'auto';
  sendBtn.disabled = true;

  addMessage('user', text);
  const typingEl = addTyping();

  try {
    const result = await window.lumo.sendMessage(text);
    typingEl.remove();
    addMessage('assistant', result.text);
  } catch (err) {
    typingEl.remove();
    addMessage('assistant', "Something went wrong on my end.");
  } finally {
    sendBtn.disabled = false;
    refreshStats();
    inputEl.focus();
  }
}

sendBtn.addEventListener('click', send);
inputEl.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    send();
  }
});
inputEl.addEventListener('input', () => {
  inputEl.style.height = 'auto';
  inputEl.style.height = Math.min(100, inputEl.scrollHeight) + 'px';
});

loadHistory();
refreshStats();
inputEl.focus();
