// preload.js
// Runs in an isolated context with access to Node — bridges a small,
// deliberate API onto `window.lumo` for the renderer. Nothing else
// from Node/Electron is exposed to the page.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('lumo', {
  // overlay window movement
  setWindowX: (x) => ipcRenderer.send('set-window-x', x),
  getScreenBounds: () => ipcRenderer.invoke('get-screen-bounds'),
  getCursorPoint: () => ipcRenderer.invoke('get-cursor-point'),
  onCallToCursor: (cb) => ipcRenderer.on('call-to-cursor', (_e, point) => cb(point)),

  // windows
  openChat: () => ipcRenderer.send('open-chat'),
  quit: () => ipcRenderer.send('quit-app'),

  // stats / progression
  getStats: () => ipcRenderer.invoke('get-stats'),
  addXp: (amount) => ipcRenderer.invoke('add-xp', amount),
  adjustStat: (key, delta) => ipcRenderer.invoke('adjust-stat', { key, delta }),
  addFriendship: (amount) => ipcRenderer.invoke('add-friendship', amount),

  // memory
  getMemory: () => ipcRenderer.invoke('get-memory'),
  rememberFact: (fact) => ipcRenderer.invoke('remember-fact', fact),
  getChatHistory: () => ipcRenderer.invoke('get-chat-history'),

  // chat
  sendMessage: (text) => ipcRenderer.invoke('chat-send', text)
});
