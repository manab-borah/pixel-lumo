// store.js
// Tiny JSON-file persistence layer. No database needed for a desktop pet.
const fs = require('fs');
const path = require('path');

const DEFAULT_STATE = {
  stats: {
    level: 1,
    xp: 0,
    health: 100,
    energy: 100,
    happiness: 80,
    friendship: 0
  },
  memory: [], // array of { fact, savedAt }
  chatHistory: [] // array of { role: 'user'|'assistant', content, at }
};

class Store {
  constructor(userDataDir) {
    this.filePath = path.join(userDataDir, 'lumo-state.json');
    this.state = this._load();
  }

  _load() {
    try {
      const raw = fs.readFileSync(this.filePath, 'utf-8');
      const parsed = JSON.parse(raw);
      // merge with defaults so new fields added in future versions don't break old saves
      return {
        stats: { ...DEFAULT_STATE.stats, ...(parsed.stats || {}) },
        memory: parsed.memory || [],
        chatHistory: parsed.chatHistory || []
      };
    } catch (err) {
      return JSON.parse(JSON.stringify(DEFAULT_STATE));
    }
  }

  save() {
    try {
      fs.writeFileSync(this.filePath, JSON.stringify(this.state, null, 2), 'utf-8');
    } catch (err) {
      console.error('[store] failed to save state:', err);
    }
  }

  getStats() {
    return this.state.stats;
  }

  addXp(amount) {
    const s = this.state.stats;
    s.xp += amount;
    const xpToLevel = s.level * 100;
    if (s.xp >= xpToLevel) {
      s.xp -= xpToLevel;
      s.level += 1;
    }
    this.save();
    return s;
  }

  adjustStat(key, delta) {
    const s = this.state.stats;
    if (!(key in s)) return s;
    s[key] = Math.max(0, Math.min(100, s[key] + delta));
    this.save();
    return s;
  }

  addFriendship(amount) {
    this.state.stats.friendship = Math.max(0, this.state.stats.friendship + amount);
    this.save();
    return this.state.stats;
  }

  rememberFact(fact) {
    this.state.memory.push({ fact, savedAt: Date.now() });
    // keep memory bounded so it doesn't grow forever
    if (this.state.memory.length > 200) {
      this.state.memory = this.state.memory.slice(-200);
    }
    this.save();
    return this.state.memory;
  }

  getMemory() {
    return this.state.memory;
  }

  pushChatMessage(role, content) {
    this.state.chatHistory.push({ role, content, at: Date.now() });
    if (this.state.chatHistory.length > 60) {
      this.state.chatHistory = this.state.chatHistory.slice(-60);
    }
    this.save();
    return this.state.chatHistory;
  }

  getChatHistory() {
    return this.state.chatHistory;
  }
}

module.exports = { Store, DEFAULT_STATE };
