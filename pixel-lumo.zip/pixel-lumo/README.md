# Pixel Lumo

A tiny creature that lives on the bottom edge of your screen, wanders around,
reacts to how you treat it, and opens into an AI chat when you double-click it.

This build covers your top-5 priority list end to end:

1. **Bottom-only walking system** — Lumo is a small transparent window that
   repositions itself along your screen's work area. No sprite assets needed;
   it's drawn procedurally on canvas, so it runs immediately.
2. **Idle / sleep / dance / angry animations** — plus surprised, stretch, and
   a walk cycle, all driven by one state machine in `overlay/renderer.js`.
3. **Mood + personality** — clicking, ignoring, and calling Lumo all feed into
   its behavior (see "How the personality works" below).
4. **Double-click AI chat** — opens a separate window wired to the real
   Claude API, with a fully working offline fallback if you haven't added a
   key yet.
5. **XP + friendship + leveling** — persisted to disk between launches.

Mini-games and the "tiny world" room from your list aren't built yet — they're
naturally a phase 2 on top of this (see "What's next").

## Setup

```bash
npm install
npm start
```

Requires Node.js 18+. First run needs `npm install` to pull down Electron
(~150MB download, one time).

### Adding real AI chat

Without a key, double-clicking Lumo still opens a working chat with canned
offline replies — nothing crashes, nothing's blocked.

To get real responses:

1. Copy `config.example.json` to `config.json`.
2. Put your Anthropic API key in it: `{ "anthropicApiKey": "sk-ant-..." }`.
3. Restart the app.

`config.json` is git-ignored, and the API call happens in the **main
process** (`main.js`), never in the renderer — so the key is never sitting in
inspectable front-end code.

## How the personality works

- **Left alone ~45s** → Lumo falls asleep (shortened from a longer real value
  for testing — see `SLEEP_AFTER_IDLE_MS` in `renderer.js`).
- **Ignored ~5 min** → does a little dance, per your spec (`DANCE_AFTER_IDLE_MS`).
- **Click it once** → happy little "hey!" reaction, +1 friendship.
- **Click it 5+ times in 4 seconds** → gets annoyed, happiness drops.
- **Double-click** → opens the chat window.
- **Alt+L (global shortcut)** → "calls" Lumo, which runs toward your cursor.
- **Right-click** → asks for confirmation, then quits.
- Every couple of seconds Lumo's internal loop (`decide()` in `renderer.js`)
  picks its next behavior — wander a little, stretch, or say a random
  thought/joke — so it never looks frozen even when you're not touching it.

## Architecture

```
main.js        Electron main process: owns the transparent overlay window,
                the chat window, global shortcut, and the server-side Claude
                API call.
preload.js      Narrow, explicit bridge from renderer -> main (contextBridge).
store.js        JSON-file persistence for stats / memory / chat history,
                saved to Electron's userData directory.
overlay/        The on-screen character: canvas rendering + state machine.
chat/           The chat window UI.
```

Stats and remembered facts live in a JSON file in your OS's app-data folder
(via `app.getPath('userData')`), so they survive restarts.

## What's next (from your full feature list)

Good next steps, roughly in order of how naturally they build on this
foundation:

- **Real sprite art** — swap the procedural `draw()` calls in
  `overlay/renderer.js` for a sprite-sheet animator once you have art;
  the state machine driving it doesn't need to change.
- **PC awareness** (detect typing, active window/app) — this is the one
  feature on your list that touches sensitive territory (reading what
  program the user has open). Worth building as an explicit opt-in toggle
  rather than always-on, and scoped to "which app is focused," not
  keystroke content.
- **Mini-games** — each is really its own small canvas scene; the XP/leveling
  plumbing (`store.addXp`) is already there for them to hook into.
- **Tiny world / room view** — a second window (or a mode swap on the chat
  window) that renders a 2D room instead of the chat UI, reusing the same
  stats file.

## Known limitations

- Tested design targets Windows/macOS/Linux via Electron, but multi-monitor
  edge cases (Lumo walking off the edge of one screen onto another) aren't
  handled yet — it's clamped to the primary display's work area for now.
- No packaged installer yet (`npm start` runs it in dev mode). When you're
  ready to ship, `electron-builder` is the standard next step.
