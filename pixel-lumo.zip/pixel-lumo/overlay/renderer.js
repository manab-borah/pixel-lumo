// renderer.js
// Everything that makes Lumo feel alive: the state machine, the walk cycle,
// mood decisions, and the click/double-click interactions. Drawing is all
// procedural canvas (no sprite sheet needed) so this runs out of the box —
// swap draw() for a sprite-sheet renderer later without touching the logic.

const canvas = document.getElementById('lumo-canvas');
const ctx = canvas.getContext('2d');

const WIN_W = 160;
const WIN_H = 170;
const GROUND_Y = 140; // where Lumo's feet sit inside the canvas

// ---- Tunable timings (ms). Shortened from the real "~5 min" spec in a
// couple of spots with a comment, so you can actually see behavior while
// testing — bump them back up for the real build. ----
const SLEEP_AFTER_IDLE_MS = 45_000;       // no interaction -> falls asleep
const DANCE_AFTER_IDLE_MS = 5 * 60_000;   // true to spec: dance after ~5 min ignored
const THOUGHT_MIN_MS = 20_000;
const THOUGHT_MAX_MS = 45_000;
const WALK_SPEED = 40;   // px/sec
const RUN_SPEED = 110;   // px/sec
const CLICK_ANNOY_WINDOW_MS = 4000;
const CLICK_ANNOY_THRESHOLD = 5;

const RANDOM_THOUGHTS = [
  "hm.",
  "wonder what's in that folder...",
  "*stares at the taskbar*",
  "you should save your work.",
  "is it snack time yet?",
  "counting pixels again.",
  "quietly judging your tab count.",
  "..."
];

const JOKES = [
  "why did the file cross the folder? new home directory.",
  "I'd tell you a UDP joke but you might not get it.",
  "I'm not lazy, I'm in idle state."
];

let screenBounds = null; // filled in async on load

const state = {
  mode: 'idle', // idle | walk | run | sleep | dance | angry | surprised | talk | stretch
  facing: 1,
  windowX: 40,
  targetX: null,
  running: false,
  lastInteraction: Date.now(),
  clickTimestamps: [],
  singleClickTimer: null,
  blinkAt: 0,
  bubble: null, // { text, until }
  nextThoughtAt: Date.now() + rand(THOUGHT_MIN_MS, THOUGHT_MAX_MS),
  modeUntil: 0, // some modes (angry, surprised, stretch) auto-expire
  local: { happiness: 80, energy: 100 } // lightweight mirror; source of truth is main via store
};

function rand(min, max) { return min + Math.random() * (max - min); }
function now() { return Date.now(); }

async function init() {
  const bounds = await window.lumo.getScreenBounds();
  screenBounds = bounds.workArea;
  state.windowX = screenBounds.x + 40;
  window.lumo.setWindowX(state.windowX);

  window.lumo.onCallToCursor((point) => {
    setMode('walk');
    state.running = true;
    state.targetX = clampTargetX(point.x - WIN_W / 2);
    say("coming!");
  });

  requestAnimationFrame(loop);
  scheduleNextDecision();
}

function clampTargetX(x) {
  if (!screenBounds) return x;
  const min = screenBounds.x;
  const max = screenBounds.x + screenBounds.width - WIN_W;
  return Math.max(min, Math.min(max, x));
}

function setMode(mode, durationMs) {
  state.mode = mode;
  state.modeUntil = durationMs ? now() + durationMs : 0;
}

function say(text, ms = 3200) {
  state.bubble = { text, until: now() + ms };
}

function markInteraction() {
  state.lastInteraction = now();
  state.local.energy = Math.min(100, state.local.energy + 2);
}

// ---- Idle "AI" loop: every couple seconds, decide what Lumo should be doing ----
function scheduleNextDecision() {
  decide();
  setTimeout(scheduleNextDecision, 2000);
}

function decide() {
  const idleFor = now() - state.lastInteraction;

  // Interruptible / timed states run their course untouched.
  if (['angry', 'surprised', 'stretch', 'talk'].includes(state.mode)) {
    if (state.modeUntil && now() > state.modeUntil) setMode('idle');
    return;
  }

  if (state.mode === 'sleep') {
    if (idleFor < SLEEP_AFTER_IDLE_MS) setMode('idle'); // something woke it up
    return;
  }

  if (state.mode === 'dance') {
    if (state.modeUntil && now() > state.modeUntil) setMode('idle');
    return;
  }

  if (idleFor > DANCE_AFTER_IDLE_MS) {
    setMode('dance', 6000);
    say("nobody's watching, so... 💃");
    return;
  }

  if (idleFor > SLEEP_AFTER_IDLE_MS) {
    setMode('sleep');
    return;
  }

  if (state.mode === 'walk' || state.mode === 'run') return; // let current walk finish

  // Otherwise, small chance to wander a bit so Lumo doesn't feel static.
  if (Math.random() < 0.35) {
    const delta = rand(-90, 90);
    state.targetX = clampTargetX(state.windowX + delta);
    state.facing = state.targetX > state.windowX ? 1 : -1;
    state.running = false;
    setMode('walk');
  } else if (Math.random() < 0.15) {
    setMode('stretch', 1400);
  }

  if (now() > state.nextThoughtAt && state.mode !== 'sleep') {
    const pool = Math.random() < 0.3 ? JOKES : RANDOM_THOUGHTS;
    say(pool[Math.floor(Math.random() * pool.length)]);
    state.nextThoughtAt = now() + rand(THOUGHT_MIN_MS, THOUGHT_MAX_MS);
  }
}

// ---- Interaction handling ----
canvas.addEventListener('click', () => {
  markInteraction();
  state.clickTimestamps.push(now());
  state.clickTimestamps = state.clickTimestamps.filter(t => now() - t < CLICK_ANNOY_WINDOW_MS);

  if (state.clickTimestamps.length >= CLICK_ANNOY_THRESHOLD) {
    setMode('angry', 2500);
    say("okay, that's enough clicking!");
    window.lumo.adjustStat('happiness', -5);
    state.clickTimestamps = [];
    return;
  }

  if (state.singleClickTimer) {
    clearTimeout(state.singleClickTimer);
    state.singleClickTimer = null;
    return; // this click is part of a dblclick, handled below
  }
  state.singleClickTimer = setTimeout(() => {
    state.singleClickTimer = null;
    setMode('surprised', 900);
    say(Math.random() < 0.5 ? "hey!" : "hi there!");
    window.lumo.addFriendship(1);
  }, 220);
});

canvas.addEventListener('dblclick', () => {
  markInteraction();
  setMode('talk', 800);
  window.lumo.openChat();
});

canvas.addEventListener('contextmenu', (e) => {
  e.preventDefault();
  if (window.confirm('Put Lumo away for now?')) {
    window.lumo.quit();
  }
});

// ---- Physics / movement ----
let lastTs = performance.now();
function loop(ts) {
  const dt = Math.min(0.05, (ts - lastTs) / 1000);
  lastTs = ts;
  update(dt);
  draw();
  requestAnimationFrame(loop);
}

function update(dt) {
  if ((state.mode === 'walk' || state.mode === 'run') && state.targetX !== null) {
    const speed = state.running ? RUN_SPEED : WALK_SPEED;
    const dir = state.targetX > state.windowX ? 1 : -1;
    state.facing = dir;
    state.windowX += dir * speed * dt;

    if (Math.abs(state.targetX - state.windowX) < 4) {
      state.windowX = state.targetX;
      state.targetX = null;
      state.running = false;
      setMode('idle');
    }
    window.lumo.setWindowX(state.windowX);
  }

  if (state.bubble && now() > state.bubble.until) state.bubble = null;
}

// ---- Drawing ----
function draw() {
  ctx.clearRect(0, 0, WIN_W, WIN_H);

  const t = now() / 1000;
  ctx.save();
  ctx.translate(WIN_W / 2, 0);
  ctx.scale(state.facing, 1);
  ctx.translate(-WIN_W / 2, 0);

  drawShadow();

  switch (state.mode) {
    case 'sleep': drawSleeping(t); break;
    case 'dance': drawDancing(t); break;
    case 'angry': drawBody(t, { squish: 0.05, brow: 'angry', mouth: 'angry', color: '#e05a4e' }); break;
    case 'surprised': drawBody(t, { squish: -0.08, brow: 'surprised', mouth: 'o', color: '#ffb15e' }); break;
    case 'stretch': drawStretch(t); break;
    case 'talk': drawBody(t, { squish: 0.02, brow: 'happy', mouth: 'smile', color: '#ffb15e' }); break;
    case 'walk':
    case 'run': drawWalking(t); break;
    default: drawBody(t, { squish: 0, brow: 'idle', mouth: 'smile', color: '#ffb15e', breathing: true });
  }

  ctx.restore();

  // Speech bubble drawn AFTER the flip-restore so text never mirrors.
  if (state.bubble) drawBubble(state.bubble.text);
}

function drawShadow() {
  ctx.save();
  ctx.globalAlpha = 0.25;
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.ellipse(WIN_W / 2, GROUND_Y + 18, 26, 6, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

// Base body draw used by idle/angry/surprised/talk states.
function drawBody(t, opts) {
  const { squish = 0, brow = 'idle', mouth = 'smile', color = '#ffb15e', breathing = false } = opts;
  const breathe = breathing ? Math.sin(t * 2) * 2 : 0;
  const cx = WIN_W / 2;
  const cy = GROUND_Y - 30 + breathe;
  const bodyW = 42 * (1 + squish);
  const bodyH = 46 * (1 - squish * 0.6);

  // body (blob)
  ctx.fillStyle = color;
  ctx.strokeStyle = 'rgba(0,0,0,0.25)';
  ctx.lineWidth = 2;
  roundBlob(cx, cy, bodyW, bodyH);
  ctx.fill();
  ctx.stroke();

  // feet
  ctx.fillStyle = 'rgba(0,0,0,0.2)';
  ctx.beginPath();
  ctx.ellipse(cx - 14, GROUND_Y + 2, 9, 5, 0, 0, Math.PI * 2);
  ctx.ellipse(cx + 14, GROUND_Y + 2, 9, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  drawFace(cx, cy - 4, brow, mouth, t);
}

function drawWalking(t) {
  const strideSpeed = state.running ? 9 : 5.5;
  const bob = Math.abs(Math.sin(t * strideSpeed)) * 6;
  const cx = WIN_W / 2;
  const cy = GROUND_Y - 30 - bob;

  ctx.fillStyle = state.running ? '#ffcf6e' : '#ffb15e';
  ctx.strokeStyle = 'rgba(0,0,0,0.25)';
  ctx.lineWidth = 2;
  roundBlob(cx, cy, 40, 44);
  ctx.fill();
  ctx.stroke();

  // alternating feet
  const legPhase = Math.sin(t * strideSpeed);
  ctx.fillStyle = 'rgba(0,0,0,0.2)';
  ctx.beginPath();
  ctx.ellipse(cx - 14, GROUND_Y + 2 - legPhase * 4, 9, 5, 0, 0, Math.PI * 2);
  ctx.ellipse(cx + 14, GROUND_Y + 2 + legPhase * 4, 9, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  drawFace(cx, cy - 4, 'happy', 'smile', t);
}

function drawSleeping(t) {
  const cx = WIN_W / 2;
  const cy = GROUND_Y - 10;
  const breathe = Math.sin(t * 1.5) * 2;

  ctx.fillStyle = '#8f7bd6';
  ctx.strokeStyle = 'rgba(0,0,0,0.25)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.ellipse(cx, cy, 44 + breathe, 22, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // closed eyes (two little arcs)
  ctx.strokeStyle = '#2b2438';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(cx - 10, cy - 4, 4, 0, Math.PI, false);
  ctx.arc(cx + 10, cy - 4, 4, 0, Math.PI, false);
  ctx.stroke();

  // Zzz
  ctx.fillStyle = '#2b2438';
  ctx.font = 'bold 14px sans-serif';
  ctx.fillText('z', cx + 30, cy - 20 - Math.sin(t) * 4);
  ctx.font = 'bold 10px sans-serif';
  ctx.fillText('z', cx + 40, cy - 30 - Math.sin(t + 1) * 4);
}

function drawDancing(t) {
  const cx = WIN_W / 2 + Math.sin(t * 6) * 10;
  const cy = GROUND_Y - 30 + Math.abs(Math.sin(t * 6)) * -10;
  const wobble = Math.sin(t * 6) * 0.15;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(wobble);
  ctx.fillStyle = '#ff8fd0';
  ctx.strokeStyle = 'rgba(0,0,0,0.25)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.ellipse(0, 0, 40, 44, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  drawFace(0, -4, 'happy', 'open', t);
  ctx.restore();

  // little musical note
  ctx.fillStyle = '#ff8fd0';
  ctx.font = 'bold 16px sans-serif';
  ctx.fillText('♪', cx + 34, cy - 30 + Math.sin(t * 6) * 6);
}

function drawStretch(t) {
  const cx = WIN_W / 2;
  const cy = GROUND_Y - 26;
  const stretchAmt = Math.sin(t * 3) * 0.5 + 0.5;

  ctx.fillStyle = '#ffb15e';
  ctx.strokeStyle = 'rgba(0,0,0,0.25)';
  ctx.lineWidth = 2;
  roundBlob(cx, cy, 40 + stretchAmt * 12, 40 - stretchAmt * 8);
  ctx.fill();
  ctx.stroke();
  drawFace(cx, cy - 2, 'idle', 'o', t);
}

function roundBlob(cx, cy, w, h) {
  ctx.beginPath();
  ctx.ellipse(cx, cy, w / 2, h / 2, 0, 0, Math.PI * 2);
}

function drawFace(cx, cy, brow, mouth, t) {
  const blinking = (Math.sin(t * 0.6) > 0.985);
  ctx.fillStyle = '#2b2438';

  // eyes
  if (blinking) {
    ctx.fillRect(cx - 13, cy - 2, 8, 2);
    ctx.fillRect(cx + 5, cy - 2, 8, 2);
  } else {
    ctx.beginPath();
    ctx.arc(cx - 9, cy - 2, 4, 0, Math.PI * 2);
    ctx.arc(cx + 9, cy - 2, 4, 0, Math.PI * 2);
    ctx.fill();
  }

  // brows
  ctx.strokeStyle = '#2b2438';
  ctx.lineWidth = 2;
  if (brow === 'angry') {
    ctx.beginPath();
    ctx.moveTo(cx - 15, cy - 12); ctx.lineTo(cx - 5, cy - 8);
    ctx.moveTo(cx + 15, cy - 12); ctx.lineTo(cx + 5, cy - 8);
    ctx.stroke();
  } else if (brow === 'surprised') {
    ctx.beginPath();
    ctx.arc(cx - 9, cy - 10, 3, 0, Math.PI * 2);
    ctx.arc(cx + 9, cy - 10, 3, 0, Math.PI * 2);
    ctx.stroke();
  }

  // mouth
  ctx.beginPath();
  if (mouth === 'smile') {
    ctx.arc(cx, cy + 6, 6, 0.15 * Math.PI, 0.85 * Math.PI);
  } else if (mouth === 'angry') {
    ctx.arc(cx, cy + 14, 6, 1.15 * Math.PI, 1.85 * Math.PI);
  } else if (mouth === 'o' || mouth === 'open') {
    ctx.arc(cx, cy + 9, 3, 0, Math.PI * 2);
  }
  ctx.stroke();
}

function drawBubble(text) {
  ctx.font = '11px "Segoe UI", sans-serif';
  const padding = 8;
  const textWidth = ctx.measureText(text).width;
  const bw = Math.min(WIN_W - 10, textWidth + padding * 2);
  const bh = 26;
  const bx = (WIN_W - bw) / 2;
  const by = 20;

  ctx.fillStyle = 'rgba(20, 19, 28, 0.92)';
  ctx.strokeStyle = 'rgba(255,255,255,0.15)';
  ctx.lineWidth = 1;
  roundRect(bx, by, bw, bh, 8);
  ctx.fill();
  ctx.stroke();

  // little tail pointing down at Lumo
  ctx.beginPath();
  ctx.moveTo(WIN_W / 2 - 5, by + bh);
  ctx.lineTo(WIN_W / 2 + 5, by + bh);
  ctx.lineTo(WIN_W / 2, by + bh + 6);
  ctx.closePath();
  ctx.fillStyle = 'rgba(20, 19, 28, 0.92)';
  ctx.fill();

  ctx.fillStyle = '#f2efe9';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, WIN_W / 2, by + bh / 2, bw - padding);
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
}

function roundRect(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

init();
